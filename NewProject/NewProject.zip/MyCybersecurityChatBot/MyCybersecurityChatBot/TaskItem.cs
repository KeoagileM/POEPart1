﻿namespace MyCybersecurityChatBot
{
    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? Reminder { get; set; }
        public bool IsCompleted { get; set; }

        public string ReminderInfo
        {
            get
            {
                if (Reminder.HasValue)
                {
                    return $"Reminder: {Reminder.Value.ToShortDateString()}";
                }
                return "No reminder set";
            }
        }
    }
}