﻿using MyCybersecurityChatBot;
using System.Collections;
using System.Text;
using System.Text.RegularExpressions;

namespace MyCybersecurityChatBot
{
    public class Interactions
    {
        // Dictionary for topics and responses
        Dictionary<string, List<string>> topicResponses = new Dictionary<string, List<string>>();

        // Default responses
        List<string> defaults = new List<string>();

        // Memory
        ArrayList favouriteTopic = new ArrayList();
        string feelingTopic = "";
        string lastTopic = "";

        public List<TaskItem> Tasks { get; } = new List<TaskItem>();

        public Interactions()
        {
            // Initialize topics and responses
            getFacts objGetFacts = new getFacts();
            objGetFacts.gettingFacts(topicResponses);
            objGetFacts.defaultResponses(defaults);
        }

        public string userName(string name)
        {
            if (string.IsNullOrEmpty(name) || !Regex.IsMatch(name, @"^[A-Za-z]+$"))
            {
                return "Please enter a valid name using only letters.";
            }
            else
            {
                return $"Hello {name}, welcome to the Cybersecurity Chatbot!\nHow can I help you?";
            }
        }

        public string userFeeling(string feelings, string name)
        {
            if (feelings.Contains("yes"))
            {
                return $"Chatbot: --> That sounds great {name}";
            }
            else if (feelings.Contains("yes"))
            {
                return $"Chatbot: --> Sorry to hear that {name} remember tough times never last";
            }
            else
            {
                return $"Chatbot: --> Please answer with a yes or a no {name}";
            }
        }

        public string GetResponse(string userInput)
        {
            string response = userInput.ToLower();
            string message = "";
            bool found = false;
            Random random = new Random();

            if ((response.Contains("more") || response.Contains("detail")) && !string.IsNullOrEmpty(lastTopic))
            {
                var responses = topicResponses[lastTopic];
                return responses[random.Next(responses.Count)];
            }

            foreach (var messages in topicResponses)
            {
                string keyword = messages.Key;

                if (response.Contains(keyword))
                {
                    var responses = messages.Value;
                    message = responses[random.Next(responses.Count)];
                    lastTopic = keyword;
                    found = true;

                    foreach (string item in favouriteTopic)
                    {
                        if (response.Contains(item))
                        {
                            message = $"As someone interested in {item}, knowing that {responses[random.Next(responses.Count)]}";
                        }
                    }

                    if (response.Contains("interested") || response.Contains("love") || response.Contains("like"))
                    {
                        message = $"Amazing, I’ll remember you are interested in {keyword}.";
                        favouriteTopic.Add(keyword);
                    }

                    if (response.Contains("worried") || response.Contains("worries") || response.Contains("worrying"))
                    {
                        feelingTopic = keyword;
                        message = $"It's okay to be worried about {feelingTopic}. Just know that {responses[random.Next(responses.Count)]}";
                    }

                    if (response.Contains("curious"))
                    {
                        feelingTopic = keyword;
                        message = $"Being curious about {feelingTopic} is great! Knowing that {responses[random.Next(responses.Count)]} can help.";
                    }

                    if (response.Contains("frustrated") || response.Contains("frustrating") || response.Contains("frustrates"))
                    {
                        feelingTopic = keyword;
                        message = $"Being frustrated about {feelingTopic} is valid. But learning that {responses[random.Next(responses.Count)]} might help.";
                    }

                    if (response.Contains("angry") || response.Contains("angries"))
                    {
                        feelingTopic = keyword;
                        message = $"{feelingTopic} can make people angry. Knowing that {responses[random.Next(responses.Count)]} might help.";
                    }

                    break;
                }
            }

            if (found)
            {
                return $"{message} \n\nWould you like me to tell you more or you want to know somethhing else about security";
            }
            else if (response.Contains("exit"))
            {
                return "Thank you for using our chatbot.";
            }
            else
            {
                return defaults[random.Next(defaults.Count)];
            }
        }

        public string AddTask(string title, string description)
        {
            Tasks.Add(new TaskItem { Title = title, Description = description });
            return $"Task added with the description \"{description}\". Would you like a reminder?";
        }

        public string SetTaskReminder(string title, DateTime reminder)
        {
            var task = Tasks.FirstOrDefault(t => t.Title == title && !t.IsCompleted);
            if (task != null)
            {
                task.Reminder = reminder;
                return $"Got it! I'll remind you in {(reminder - DateTime.Now).Days} days.";
            }
            return "Task not found.";
        }

        public string ListTasks()
        {
            if (!Tasks.Any())
                return "You have no tasks.";
            var sb = new StringBuilder();
            foreach (var t in Tasks)
            {
                sb.AppendLine($"- {t.Title}: {t.Description}" +
                    (t.Reminder.HasValue ? $" (Reminder: {t.Reminder.Value:g})" : "") +
                    (t.IsCompleted ? " [Completed]" : ""));
            }
            return sb.ToString();
        }

        public string CompleteTask(string title)
        {
            var task = Tasks.FirstOrDefault(t => t.Title == title && !t.IsCompleted);
            if (task != null)
            {
                task.IsCompleted = true;
                return $"Task \"{title}\" marked as completed.";
            }
            return "Task not found.";
        }

        public string DeleteTask(string title)
        {
            var task = Tasks.FirstOrDefault(t => t.Title == title);
            if (task != null)
            {
                Tasks.Remove(task);
                return $"Task \"{title}\" deleted.";
            }
            return "Task not found.";
        }
    }
}