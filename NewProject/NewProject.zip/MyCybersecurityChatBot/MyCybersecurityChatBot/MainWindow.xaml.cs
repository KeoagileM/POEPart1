﻿using MyCybersecurityChatBot;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Microsoft.ML;
using Microsoft.ML.Data;

namespace MyCybersecurityChatBot
{
    public partial class MainWindow : Window
    {
        // User information
        private string userName = "";
        private string userInterest = "";

        // Task management
        private List<TaskItem> tasks = new List<TaskItem>();

        // Quiz management
        private List<QuizQuestion> quizQuestions = new List<QuizQuestion>();
        private int currentQuestionIndex = 0;
        private int quizScore = 0;

        // Activity log
        private List<ActivityLogEntry> activityLogEntries = new List<ActivityLogEntry>();

        // Chatbot interactions
        private Interactions chatbotInteractions = new Interactions();

        // User feeling tracking
        private bool awaitingFeeling = false;
        private string userFeelingStatus = "";

        // ML.NET context for sentiment analysis
        private readonly MLContext mlContext = new MLContext();
        private List<SentimentData> trainingData;
        private PredictionEngine<SentimentData, SentimentPrediction> predEngine;

        // Sentiment input data class for ML.NET
        private class SentimentData
        {
            public string Text { get; set; }
            public bool Label { get; set; }
        }

        // Sentiment prediction result class for ML.NET
        private class SentimentPrediction
        {
            [ColumnName("PredictedLabel")]
            public bool Prediction { get; set; }
            public float Probability { get; set; }
            public float Score { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();
            new VoiceMessage(); // Play welcome message on startup
            InitializeQuizQuestions(); // Load quiz questions
            ShowWelcomeMessage(); // Greet user
            LogActivity("Application started");

            // Initialize with base training data for sentiment analysis
            trainingData = new List<SentimentData>
            {
                new SentimentData { Text = "I am happy", Label = true },
                new SentimentData { Text = "I hate this", Label = false },
                new SentimentData { Text = "I am sad", Label = false },
                new SentimentData { Text = "I am good", Label = true }
            };

            TrainSentimentModel(); // Train the ML.NET model
        }

        // Train or retrain the ML.NET sentiment model
        private void TrainSentimentModel()
        {
            var trainDataView = mlContext.Data.LoadFromEnumerable(trainingData);

            var pipeline = mlContext.Transforms.Text.FeaturizeText("Features", nameof(SentimentData.Text))
                .Append(mlContext.BinaryClassification.Trainers.SdcaLogisticRegression(labelColumnName: "Label", featureColumnName: "Features"));

            var model = pipeline.Fit(trainDataView);

            predEngine = mlContext.Model.CreatePredictionEngine<SentimentData, SentimentPrediction>(model);
        }

        // Add all quiz questions to the quizQuestions list
        private void InitializeQuizQuestions()
        {
            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do if you receive an email asking for your password?",
                Options = new string[] { "Reply with your password", "Delete the email", "Report the email as phishing", "Ignore it" },
                CorrectAnswerIndex = 2,
                Explanation = "You should report phishing attempts to help protect others."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "Which of these is the strongest password?",
                Options = new string[] { "password123", "P@ssw0rd!", "Blue42Sky#9!", "12345678" },
                CorrectAnswerIndex = 2,
                Explanation = "Long passwords with a mix of character types are strongest."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is two-factor authentication?",
                Options = new string[] {
                    "Using two different passwords",
                    "A second layer of security beyond just a password",
                    "Having two user accounts",
                    "A type of firewall" },
                CorrectAnswerIndex = 1,
                Explanation = "2FA requires a second verification step, like a code sent to your phone."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "True or False: Public Wi-Fi networks are generally safe for online banking.",
                Options = new string[] { "True", "False" },
                CorrectAnswerIndex = 1,
                Explanation = "Public Wi-Fi is often unsecured. Avoid sensitive transactions on these networks."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do before clicking a link in an email?",
                Options = new string[] {
                    "Click it immediately if it looks interesting",
                    "Hover over it to see the actual URL first",
                    "Forward it to friends to see if they think it's safe",
                    "Check if the email has lots of spelling mistakes" },
                CorrectAnswerIndex = 1,
                Explanation = "Always verify links by hovering to see the actual destination URL."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "How often should you update your software and apps?",
                Options = new string[] {
                    "Only when they stop working",
                    "Once a year",
                    "Whenever updates are available",
                    "Never, updates often cause problems" },
                CorrectAnswerIndex = 2,
                Explanation = "Regular updates patch security vulnerabilities."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What is a common sign of a phishing attempt?",
                Options = new string[] {
                    "A sense of urgency in the message",
                    "A legitimate-looking logo",
                    "A request for personal information",
                    "All of the above" },
                CorrectAnswerIndex = 3,
                Explanation = "Phishing attempts often use all these tactics to trick users."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "Where should you store your passwords?",
                Options = new string[] {
                    "In a notebook by your computer",
                    "In a text file on your desktop",
                    "In your browser's password manager",
                    "In a dedicated password manager app" },
                CorrectAnswerIndex = 3,
                Explanation = "Dedicated password managers offer the best security."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "What should you do if you suspect your account has been hacked?",
                Options = new string[] {
                    "Change your password immediately",
                    "Check for unauthorized activity",
                    "Enable two-factor authentication if available",
                    "All of the above" },
                CorrectAnswerIndex = 3,
                Explanation = "All these steps help secure a compromised account."
            });

            quizQuestions.Add(new QuizQuestion
            {
                Question = "True or False: Using the same password for multiple accounts is safe as long as it's complex.",
                Options = new string[] { "True", "False" },
                CorrectAnswerIndex = 1,
                Explanation = "If one account is compromised, all accounts with that password are at risk."
            });
        }

        // Show welcome message in chat
        private void ShowWelcomeMessage()
        {
            AddMessageToChat("Cybersecurity Awareness Bot", "Hello! Welcome to the Cybersecurity Awareness Assistant. I'm here to help you stay safe online.");
            AddMessageToChat("Cybersecurity Awareness Bot", "What's your name?");
        }

        // Add a message to the chat window
        private void AddMessageToChat(string sender, string message)
        {
            Paragraph paragraph = new Paragraph();

            // Sender name in bold and colored
            Run senderRun = new Run(sender + ": ");
            senderRun.FontWeight = FontWeights.Bold;
            if (sender == "Cybersecurity Awareness Bot")
            {
                senderRun.Foreground = Brushes.DarkBlue;
            }
            else
            {
                senderRun.Foreground = Brushes.DarkGreen;
            }
            paragraph.Inlines.Add(senderRun);

            // Message text
            paragraph.Inlines.Add(new Run(message));

            rtbChat.Document.Blocks.Add(paragraph);
            rtbChat.ScrollToEnd();
        }

        // Main method to process user input from chat
        private void ProcessUserInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return;

            AddMessageToChat("You", input);

            // Handle username input
            if (string.IsNullOrEmpty(userName))
            {
                string nameResponse = chatbotInteractions.userName(input);

                if (nameResponse.Contains("invalid", StringComparison.OrdinalIgnoreCase) ||
                    nameResponse.Contains("please enter", StringComparison.OrdinalIgnoreCase) ||
                    nameResponse.Contains("try again", StringComparison.OrdinalIgnoreCase))
                {
                    AddMessageToChat("Cybersecurity Awareness Bot", nameResponse);
                    LogActivity($"User provided invalid name: {input}");
                    return;
                }

                userName = input;
                tbUserInfo.Text = $"User: {userName}";
                if (!string.IsNullOrEmpty(userInterest))
                {
                    tbUserInfo.Text += $"\nInterest: {userInterest}";
                }

                AddMessageToChat("Cybersecurity Awareness Bot", nameResponse);
                LogActivity($"User provided name: {userName}");

                // Ask about feeling
                AddMessageToChat("Cybersecurity Awareness Bot", "Are you feeling good today? (yes/no)");
                awaitingFeeling = true;
                return;
            }

            // Handle feeling input and analyze sentiment
            if (awaitingFeeling)
            {
                AnalyzeSentiment(input);
                tbUserInfo.Text += $"\nFeeling: {input}";
                awaitingFeeling = false;
                LogActivity($"User feeling input: {input}");
                AddMessageToChat("Cybersecurity Awareness Bot", "How can I help you with security today?");
                return;
            }

            // Check for special commands (task, quiz, log, help)
            if (ProcessSpecialCommands(input))
            {
                return;
            }


            // Get chatbot response for general queries
            string response = chatbotInteractions.GetResponse(input);
            AddMessageToChat("Cybersecurity Awareness Bot", response);
            LogActivity($"User query: {input}");
        }

        // Check for and process special commands in user input
        private bool ProcessSpecialCommands(string input)
        {
            input = input.ToLower();

            if (input.Contains("add task") || input.Contains("create task") || input.Contains("new task"))
            {
                BtnTasks_Click(null, null);
                AddMessageToChat("Cybersecurity Awareness Bot", "I've opened the Task Assistant for you. You can add cybersecurity tasks there.");
                return true;
            }
            else if (input.Contains("show tasks") || input.Contains("my tasks") || input.Contains("task list"))
            {
                BtnTasks_Click(null, null);
                AddMessageToChat("Cybersecurity Awareness Bot", "Here are your current cybersecurity tasks:");
                return true;
            }
            else if (input.Contains("take quiz") || input.Contains("start quiz") || input.Contains("cybersecurity quiz"))
            {
                BtnQuiz_Click(null, null);
                return true;
            }
            else if (input.Contains("activity log") || input.Contains("what have you done") || input.Contains("show history"))
            {
                BtnActivityLog_Click(null, null);
                return true;
            }
            else if (input.Contains("help"))
            {
                AddMessageToChat("Cybersecurity Awareness Bot", "I can help with:\n- Cybersecurity advice (ask about passwords, phishing, privacy)\n- Managing cybersecurity tasks (say 'add task')\n- Testing your knowledge (say 'take quiz')\n- Showing activity history (say 'activity log')");
                return true;
            }

            return false;
        }

        // Analyze the sentiment of the user's input using ML.NET
        private void AnalyzeSentiment(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                AddMessageToChat("Cybersecurity Awareness Bot", "Please enter how you are feeling.");
                return;
            }

            var prediction = predEngine.Predict(new SentimentData { Text = input });

            // Calculate positive and negative confidence scores
            float positiveScore = prediction.Probability * 100;
            float negativeScore = 100 - positiveScore;
            string emotionType = prediction.Prediction ? "Positive" : "Negative";

            // Build feedback message
            string feedback = $"{emotionType} Emotion\n" +
                              $"Positive: {positiveScore:F1}%\n" +
                              $"Negative: {negativeScore:F1}%\n";

            string reply;
            if (positiveScore > 75)
                reply = "You seem really upbeat! Keep shining.";
            else if (positiveScore > 50)
                reply = "You’re doing alright — keep your chin up!";
            else if (positiveScore > 30)
                reply = "I sense some heaviness — it’s okay to feel down sometimes.";
            else
                reply = "You seem quite low. Be kind to yourself — brighter days will come.";

            AddMessageToChat("Cybersecurity Awareness Bot", feedback + reply);

            // Ask user to confirm if prediction was correct
            var result = MessageBox.Show("Was this prediction correct?", "Feedback", MessageBoxButton.YesNo);

            if (result == MessageBoxResult.No)
            {
                // Ask what the correct label was
                var correct = MessageBox.Show("Was it actually Positive?", "Correct Label", MessageBoxButton.YesNo);
                bool correctLabel = (correct == MessageBoxResult.Yes);

                // Add to training data and retrain model
                trainingData.Add(new SentimentData { Text = input, Label = correctLabel });
                TrainSentimentModel();

                MessageBox.Show("Thanks! I've learned from that.");
            }
        }

        // Log an activity to the activity log
        private void LogActivity(string action)
        {
            activityLogEntries.Add(new ActivityLogEntry
            {
                Timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                Action = action
            });

            // Update activity log display if it's visible
            if (activityLog.Visibility == Visibility.Visible)
            {
                lbActivityLog.ItemsSource = null;
                lbActivityLog.ItemsSource = activityLogEntries;
            }
        }

        // Event handler: send button click in chat
        private void BtnSend_Click(object sender, RoutedEventArgs e)
        {
            ProcessUserInput(tbUserInput.Text);
            tbUserInput.Clear();
        }

        // Event handler: Enter key in chat input
        private void TbUserInput_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                ProcessUserInput(tbUserInput.Text);
                tbUserInput.Clear();
            }
        }

        // Event handler: show chat interface
        private void BtnChat_Click(object sender, RoutedEventArgs e)
        {
            chatInterface.Visibility = Visibility.Visible;
            taskAssistant.Visibility = Visibility.Collapsed;
            quizInterface.Visibility = Visibility.Collapsed;
            activityLog.Visibility = Visibility.Collapsed;
        }

        // Event handler: show task assistant
        private void BtnTasks_Click(object sender, RoutedEventArgs e)
        {
            chatInterface.Visibility = Visibility.Collapsed;
            taskAssistant.Visibility = Visibility.Visible;
            quizInterface.Visibility = Visibility.Collapsed;
            activityLog.Visibility = Visibility.Collapsed;

            lbTasks.ItemsSource = null;
            lbTasks.ItemsSource = tasks;
        }

        // Event handler: show quiz interface
        private void BtnQuiz_Click(object sender, RoutedEventArgs e)
        {
            chatInterface.Visibility = Visibility.Collapsed;
            taskAssistant.Visibility = Visibility.Collapsed;
            quizInterface.Visibility = Visibility.Visible;
            activityLog.Visibility = Visibility.Collapsed;

            currentQuestionIndex = 0;
            quizScore = 0;
            DisplayQuestion(currentQuestionIndex);
            LogActivity("Started cybersecurity quiz");
        }

        // Event handler: show activity log
        private void BtnActivityLog_Click(object sender, RoutedEventArgs e)
        {
            chatInterface.Visibility = Visibility.Collapsed;
            taskAssistant.Visibility = Visibility.Collapsed;
            quizInterface.Visibility = Visibility.Collapsed;
            activityLog.Visibility = Visibility.Visible;

            lbActivityLog.ItemsSource = null;
            lbActivityLog.ItemsSource = activityLogEntries;
            LogActivity("Viewed activity log");
        }

        // Event handler: add a new task
        private void BtnAddTask_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbTaskTitle.Text))
            {
                MessageBox.Show("Please enter a task title.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string reminderDays = (cbReminderDays.SelectedItem as ComboBoxItem)?.Content.ToString();
            DateTime? reminderDate = null;

            // Set reminder date if selected
            if (reminderDays != "None" && int.TryParse(reminderDays, out int days))
            {
                reminderDate = DateTime.Now.AddDays(days);
            }

            var task = new TaskItem
            {
                Title = tbTaskTitle.Text,
                Description = tbTaskDescription.Text,
                Reminder = reminderDate,
                IsCompleted = false
            };

            tasks.Add(task);
            lbTasks.ItemsSource = null;
            lbTasks.ItemsSource = tasks;

            string logMessage = $"Added task: {task.Title}";
            if (reminderDate.HasValue)
            {
                logMessage += $" (Reminder set for {reminderDate.Value.ToShortDateString()})";
            }
            LogActivity(logMessage);

            tbTaskTitle.Clear();
            tbTaskDescription.Clear();
            cbReminderDays.SelectedIndex = 0;
        }

        // Event handler: mark selected task as complete
        private void BtnMarkComplete_Click(object sender, RoutedEventArgs e)
        {
            if (lbTasks.SelectedItem is TaskItem selectedTask)
            {
                selectedTask.IsCompleted = true;
                lbTasks.ItemsSource = null;
                lbTasks.ItemsSource = tasks;
                LogActivity($"Marked task as complete: {selectedTask.Title}");
            }
            else
            {
                MessageBox.Show("Please select a task to mark as complete.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Event handler: delete selected task
        private void BtnDeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (lbTasks.SelectedItem is TaskItem selectedTask)
            {
                tasks.Remove(selectedTask);
                lbTasks.ItemsSource = null;
                lbTasks.ItemsSource = tasks;
                LogActivity($"Deleted task: {selectedTask.Title}");
            }
            else
            {
                MessageBox.Show("Please select a task to delete.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        // Event handler: update task buttons based on selection
        private void LbTasks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            btnMarkComplete.IsEnabled = lbTasks.SelectedItem != null;
            btnDeleteTask.IsEnabled = lbTasks.SelectedItem != null;
        }

        // Display a quiz question and options
        private void DisplayQuestion(int index)
        {
            if (index < 0 || index >= quizQuestions.Count) return;

            var question = quizQuestions[index];
            tbQuizQuestion.Text = question.Question;

            rbOption1.Content = question.Options[0];
            rbOption2.Content = question.Options.Length > 1 ? question.Options[1] : "";
            rbOption3.Content = question.Options.Length > 2 ? question.Options[2] : "";
            rbOption4.Content = question.Options.Length > 3 ? question.Options[3] : "";

            rbOption1.IsChecked = false;
            rbOption2.IsChecked = false;
            rbOption3.IsChecked = false;
            rbOption4.IsChecked = false;

            lblQuizProgress.Content = $"Question {index + 1} of {quizQuestions.Count}";

            btnPreviousQuestion.IsEnabled = index > 0;
            btnNextQuestion.IsEnabled = index < quizQuestions.Count - 1;
            btnSubmitQuiz.IsEnabled = index == quizQuestions.Count - 1;
        }

        // Event handler: go to previous quiz question
        private void BtnPreviousQuestion_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuestionIndex > 0)
            {
                currentQuestionIndex--;
                DisplayQuestion(currentQuestionIndex);
            }
        }

        // Event handler: go to next quiz question
        private void BtnNextQuestion_Click(object sender, RoutedEventArgs e)
        {
            if (currentQuestionIndex < quizQuestions.Count - 1)
            {
                currentQuestionIndex++;
                DisplayQuestion(currentQuestionIndex);
            }
        }

        // Event handler: submit quiz and show results
        private void BtnSubmitQuiz_Click(object sender, RoutedEventArgs e)
        {
            // Check last question answer
            CheckAnswer();

            // Show results
            string resultMessage = $"Quiz completed! Your score: {quizScore}/{quizQuestions.Count}\n";
            if (quizScore == quizQuestions.Count)
            {
                resultMessage += "Perfect! You're a cybersecurity expert!";
            }
            else if (quizScore >= quizQuestions.Count * 0.7)
            {
                resultMessage += "Good job! You have solid cybersecurity knowledge.";
            }
            else
            {
                resultMessage += "Keep learning! Review the questions to improve your cybersecurity knowledge.";
            }

            MessageBox.Show(resultMessage, "Quiz Results", MessageBoxButton.OK, MessageBoxImage.Information);
            LogActivity($"Completed quiz with score: {quizScore}/{quizQuestions.Count}");

            // Return to chat interface
            BtnChat_Click(null, null);
        }

        // Check the answer for the current quiz question
        private void CheckAnswer()
        {
            if (currentQuestionIndex < 0 || currentQuestionIndex >= quizQuestions.Count) return;

            int selectedIndex = -1;
            if (rbOption1.IsChecked == true) selectedIndex = 0;
            else if (rbOption2.IsChecked == true) selectedIndex = 1;
            else if (rbOption3.IsChecked == true) selectedIndex = 2;
            else if (rbOption4.IsChecked == true) selectedIndex = 3;

            if (selectedIndex == quizQuestions[currentQuestionIndex].CorrectAnswerIndex)
            {
                quizScore++;
            }

            lblQuizScore.Content = $"Score: {quizScore}";
        }
    }
}